﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TeamB
{
    public partial class OrderHistory
    {
        public int CustomerUserId
        {
            get;
            set;
        }

    }
}